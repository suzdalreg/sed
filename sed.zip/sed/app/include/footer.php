<div class="footer container-fluid">
    <div class="footer-content container">


        <div class="footer-bottom">
            &copy; СЭД v1.0| Designed by Kurenkov
        </div>
    </div>
</div>