<?php
session_start(); ?>
<header class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-4">
                <h3 style="margin-top: 18px;">
                    <a href="<?php echo BASE_URL ?>">СЭД Суздальский район</a>
                </h3>
            </div>
            <nav class="col-8">
                <ul>
                    <li>
                        <?php if ($_SESSION['USER_tip'] == 'admin') { ?>
                            <a href="<?php echo BASE_URL . "spravka.php"; ?>">Справочники </a>
                        <?php  }
                        $_SESSION['USER_NAME'];
                        ?>
                    </li>
                    <li>
                        <a href="#">
                            <?php
                            echo $_SESSION['NAME'];
                            ?>
                        </a>
                        <ul>

                            <li><a href="<?php echo BASE_URL . "logout.php"; ?>">Выход</a> </li>
                        </ul>
                    </li>




                </ul>
            </nav>
        </div>
    </div>
</header>