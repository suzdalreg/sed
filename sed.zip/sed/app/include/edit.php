<div class="modal fade" id="Modaledit" tabindex="-1" data-bs-backdrop="static">
  <div class="modal-dialog modal-xl" style="max-width: 1400px;">
    <div class="modal-content" id="content">
      <div id="loader"><span></span></div>
      <div class="modal-header">
        <h5 class="modal-title" id="zagolovok">Изменение записи</h5>
        <button type="button" class="btn-close" id="clos_edit" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="dob">
          <form class="in" method="POST" action="" id="edit_form" enctype="multipart/form-data">
            <div class="row">
              <div class="col">
                <div class="form-text">Исх. № </div>
                <input type="text" id="nomer_isx_edit" name=" nomer_isx" class="form-control form-control-sm" autocomplete="off" required placeholder="Исх.№">
              </div>
              <div class="col">
                <div class="form-text">Исх. дата</div>
                <input type="date" id="date_isx_edit" name="date_isx" class="form-control form-control-sm" required placeholder="Исх.дата">
              </div>
              <div class="col">
                <div class="form-text">Вх. № </div>
                <input type="text" id="nomer_vx_edit" name="nomer_vx" class="form-control form-control-sm" autocomplete="off" required placeholder="Вх.№">
              </div>
              <div class="col">
                <div class="form-text">Вх. дата</div>
                <input type="date" id="date_vx_edit" name="date_vx" class="form-control form-control-sm" required>
              </div>
              <div class="col">
                <div class="form-text">Вид документа</div>
                <select name="doc" id="vid_edit" class="form-control form-control-sm">
                  <option value="Мун. услуга">Мун. услуга</option>
                  <option value="Письмо">Письмо</option>
                </select>
              </div>
              <div class="col">
                <div id="date" class="form-text">Срок</div>
                <input type="date" id="control_ed" name="control" class="form-control form-control-sm">
              </div>
              <div class="row">
                <div class="col">
                  <input type="hidden" name="id" id="id_new_edit">
                  <input type="hidden" name="tip" value="up">
                  <div id="directed" class="form-text">Организация</div>
                  <input class="form-control form-control-sm" list="org" name="organ" id="exampleDataList">
                  <datalist id="org">
                    <?php
                    $sel = mysqli_query($CONNECT, "SELECT * FROM `org` ORDER BY `org`.`value` ASC");
                    $org = mysqli_fetch_all($sel);
                    foreach ($org as  $lib) {
                      //tt($lib);
                      echo '
                        <option value="' . $lib[1] . '">' . $lib[1] . '</option>
                        ';
                    }
                    ?>
                  </datalist>
                </div>
                <div class="col">
                  <div id="directed" class="form-text">Номенклатура</div>
                  <input class="form-control form-control-sm" name="nomenklatura" list="num" id="exampleDataList1">
                  <datalist id="num">
                    <?php
                    $select = mysqli_query($CONNECT, "SELECT * FROM `numeklatura`  ");
                    $persone = mysqli_fetch_all($select);
                    foreach ($persone as  $lib) {
                      //tt($lib);
                      echo '
                        <option value="' . $lib[1] . '">' . $lib[1] . '</option>
                        ';
                    }
                    ?>
                  </datalist>
                </div>
                <div class="col">
                  <div class="form-text">Отдел</div>
                  <select name="otdel" id="otdel" class="form-control form-control-sm">
                    <option value="org">-</option>
                    <option value="arx">Архитектура</option>
                    <option value="kumi">Куми</option>
                  </select>
                </div>
              </div>
              <div class="row">
                <div class="col">
                  <div class="form-group shadow-textarea">
                    <div id="directed" class="form-text">Аннотация</div>
                    <textarea name="title" class="form-control z-depth-1" id="title" rows="4" required placeholder="Аннотация"></textarea><br>
                  </div>
                </div>
                <div class="col">
                  <div class="form-group shadow-textarea">
                    <div id="directed" class="form-text">Отчет</div>
                    <textarea name="report" class="form-control z-depth-1" id="report" rows="4" required placeholder="Отчет об исполнении"></textarea><br>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
        <div class="isp">
          <div class="col">
            <h4 style="margin-top: 20px; color: #95423e;">Исполнители</h4>
          </div>
          <div class="dob">
            <form class="in" method="POST" action="" id="isp_form" enctype="multipart/form-data">
              <div class="row">
                <div class="col">
                  <input type="hidden" name="id" id="id_info">
                  <input type="hidden" name="tip" value="add">
                  <div class="form-text">Автор резолюции</div>
                  <select name="avtor" id="avtor" class="form-control form-control-sm">
                    <option value="Сараев А.П.">Сараев А.П.</option>
                    <option value="Срибная Т.А.">Срибная Т.А.</option>
                    <option value="Белов С.А.">Белов С.А.</option>
                    <option value="Авсеенок А.И.">Авсеенок А.И.</option>
                    <option value="Залихматская Н.Н.">Залихматская Н.Н.</option>
                    <option value="Чижикова Е.А.">Чижикова Е.А.</option>
                  </select>
                </div>
                <div class="col">
                  <div class="form-text">Резолюция</div>
                  <select name="rezolut" id="rezolut" class="form-control form-control-sm">
                    <option value="Для исполнения">Для исполнения</option>
                    <option value="Для исполнения(по поручению)">Для исполнения(по поручению)</option>
                    <option value="Для сведения">Для сведения</option>
                    <option value="Рассмотреть">Рассмотреть</option>
                  </select>
                </div>
                <div class="col">
                  <div class="form-text">Дата резолюции</div>
                  <input type="date" id="date_rez" name="date_rez" class="form-control form-control-sm">
                </div>
                <div class="col">
                  <div class="form-text">Исполнитель</div>
                  <select name="ispolnitel" id="ispolnitel" class="form-control form-control-sm">
                    <?php
                    $s = mysqli_query($CONNECT, "SELECT * FROM `person` ORDER BY `person`.`value` ASC ");
                    $p = mysqli_fetch_all($s);
                    foreach ($p as  $l) {
                      //tt($lib);
                      echo '
                        <option value="' . $l[1] . '">' . $l[1] . '</option>
                        ';
                    }
                    ?>
                  </select>
                </div>
                <div class="col">
                  <div class="form-text">Дата передачи</div>
                  <input type="date" id="date_per" name="date_per" class="form-control form-control-sm">
                </div>

                <div class="col">
                  <div id="date" class="form-text" style="color: #e3e0db59 ;">.</div>
                  <input type="button" value="Добавить" onclick="add_isp()" class="btn btn-success btn-sm">
                </div>

              </div>
              <div class="col" id="ispol">
              </div>
            </form>
          </div>
        </div>
        <div class="modal-footer" id="cotent_footer">
          <input type="button" value="Сохранить изменения" onclick="spiner_edit()" id="spiner_edit" class="btn btn-success btn-sm">
        </div>
      </div>
    </div>
  </div>
</div>