<div class="modal fade" id="Modalfile" tabindex="-1" data-bs-backdrop="static">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" id="content">
      <div class="modal-header">
        <div id="loader2"><span></span></div>
        <h5 class="modal-title" id="zagolovok">Файлы</h5>
        <button type="button" class="btn-close" id="fileclos" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="col">
          <input type="file" name="cont" id="fileup" class="form-control-file btn-sm" multiple="multiple" style="border: none;">
        </div>
        <div class="col-12 " id="list">


        </div>
      </div>
    </div>
  </div>
</div>