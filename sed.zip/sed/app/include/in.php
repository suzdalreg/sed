<div class="modal fade" id="Modalin" tabindex="-1" data-bs-backdrop="static">
  <div class="modal-dialog modal-xl" style="max-width: 1400px;">
    <div class="modal-content" id="content">
      <div id="loader"><span></span></div>
      <div class="modal-header">
        <h5 class="modal-title" id="zagolovok">Добавление записи</h5>
        <button type="button" class="btn-close" id="clos" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="dob">
          <form class="in" method="POST" action="" id="insert_form" enctype="multipart/form-data">
            <div class="row">
              <div class="col">
                <div class="form-text">Исх. № </div>
                <input type="text" id="nomer_edit" name="nomer_isx" class="form-control form-control-sm" autocomplete="off" required placeholder="Исх.№">
              </div>
              <div class="col">
                <div class="form-text">Исх. дата</div>
                <input type="date" id="date_edit" name="date_isx" class="form-control form-control-sm" required placeholder="Исх.дата">
              </div>
              <div class="col">
                <div class="form-text">Вх. № </div>
                <input type="text" id="nomer_vx" name="nomer_vx" class="form-control form-control-sm" autocomplete="off" required placeholder="Вх.№">
              </div>
              <div class="col">
                <div class="form-text">Вх. дата</div>
                <input type="date" id="date_vx" name="date_vx" class="form-control form-control-sm" required>
              </div>
              <div class="col">
                <div class="form-text">Вид документа</div>
                <select name="doc" id="vid" class="form-control form-control-sm">
                  <option value="Мун. услуга">Мун. услуга</option>
                  <option value="Письмо">Письмо</option>
                </select>
              </div>
              <div class="col">
                <div id="date" class="form-text">Срок</div>
                <input type="date" id="control_edit" name="control" class="form-control form-control-sm">
              </div>
              <div class="row">
                <div class="col">
                  <div class="form-group shadow-textarea">
                    <label for="exampleFormControlTextarea6"></label>
                    <textarea name="title" class="form-control z-depth-1" id="title_edit" rows="6" required placeholder="Аннотация"></textarea><br>
                  </div>
                </div>

                <div class="col">
                  <input type="hidden" name="id" id="id_new">
                  <input type="hidden" name="year" id="year-hid">
                  <input type="hidden" name="funс" value="in_info">
                  <div id="directed" class="form-text">Организация</div>
                  <select name="organ" class="form-select" id="search_org">
                    <?php
                    $sel = mysqli_query($CONNECT, "SELECT * FROM `org` ORDER BY `org`.`value` ASC");
                    $org = mysqli_fetch_all($sel);
                    foreach ($org as  $lib) {
                      //tt($lib);
                      echo '
                        <option value="' . $lib[1] . '">' . $lib[1] . '</option>
                        ';
                    }
                    ?>
                  </select>
                  <div id="directed" class="form-text">Номенклатура</div>
                  <select name="numorg" class="form-select" id="example-search">
                    <?php
                    $select = mysqli_query($CONNECT, "SELECT * FROM `numeklatura`  ");
                    $persone = mysqli_fetch_all($select);
                    foreach ($persone as  $lib) {
                      //tt($lib);
                      echo '
                        <option value="' . $lib[1] . '">' . $lib[1] . '</option>
                        ';
                    }
                    ?>
                  </select>
                </div>
              </div>
              <div class="col">
                <input type="file" name="cont" id="file" class="form-control-file btn-sm" multiple="multiple" style="border: none;">
              </div>
              <div class="col-5">
              </div>
            </div>
          </form>
          <div class="col-12 " id="file-list">
          </div>
        </div>
      </div>
      <div class="modal-footer" id="cotent_footer">
        <button type="submit" name="enter" id="spiner" class="btn btn-primary god">Сохранить</button>
      </div>
    </div>
  </div>
</div>