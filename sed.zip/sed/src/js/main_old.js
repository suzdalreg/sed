
/*-------------------------Получаем параметры url адреса--------------------------*/
function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}
/*------------------------/Получаем параметры url адреса---------------------------*/
/* -------------------загрузда данных --------------------------- */
function pa(razdel,year,mon) {	
   let tbody = document.getElementById("tbody");   
   let el = document.getElementById("loader");   
   el.style.display=   'block';
    fetch('load.php?razdel='+razdel+ '&year='+ year+'&mon='+mon)
    .then(data=>{
       return data.text();
    })
    .then(data=>{        
        tbody.innerHTML = data;
        el.style.display= 'none';
    })
}
/* -------------------/загрузда данных --------------------------- */


/* -----------------Просмотр статуса статуса--------------------------- */
function view_status(id,razdel){
    let myModal = new bootstrap.Modal(document.getElementById('viw_status'));  
    let tbody = document.getElementById("status_body");
    fetch('../status.php?idcat='+id+ '&id='+ razdel)
    .then(data=>{
        return data.text();
     })
     .then(data=>{        
         tbody.innerHTML = data;
         myModal.show();
     })
    
}
/* -----------------/Просмотр статуса статуса--------------------------- */


/* -----------------Изменение статуса--------------------------- */
function edit_status(id,razdel){
    let body = document.getElementById("show_status");  
    fetch('../../fun/edit_status.php?id='+id+ '&razdel='+ razdel)
    .then(data=>{
       return data.text();
    })
    .then(data=>{        
        body.innerHTML = data;
    })  
}
function add_status(event){    
    event.preventDefault();
    let form = document.getElementById('status_up');
    let razdel = document.getElementById('razdel').value;
    let id = document.getElementById('id_here').value;
    let datap = new FormData(form);
    //console.log(razdel,id);
    fetch('../../fun/add_status.php', {
        method: 'POST',
        body: datap
    })
    .then(data=>{     
        return data.text();   
         })
         .then(data=>{            
            if (data=='NO') {           
             document.getElementById('err').innerHTML ='Запись не найдена!';     
            }
            if (data=='YES') {           
                document.getElementById('err').innerHTML ='Запись уже существует!';     
               } 
               if (data=='OK') {  
                document.getElementById('err').innerHTML ='';
                document.getElementById('status_up').reset();                
                setTimeout(() => {           
                    edit_status(id,razdel);                    
                    var year = getUrlVars()["year"];
                    var mon = getUrlVars()["mon"]; 
                 pa(razdel,year,mon);
                    }, 500);
            }
        })
}
function del_status(razdel,id,id_iz){ 
console.log(razdel,id,id_iz);
fetch('../../fun/del_status.php', {
    method: 'POST',       
    body:JSON.stringify({razdel:razdel, id:id,id_iz:id_iz })       
    })
    .then(data=>{
        return data.text();            
     })   
     .then(data=>{        
        setTimeout(() => {           
            edit_status(id,razdel);
            var year = getUrlVars()["year"];
            var mon = getUrlVars()["mon"]; 
            pa(razdel,year,mon);
            }, 500);            
    })   
}

/* -----------------/Изменение статуса--------------------------- */
/* -----------------Изменение записи--------------------------- */
 function edit( razdel,id){  
    document.getElementById('insert_form').reset();
    document.getElementById('status_up').reset();  
    document.getElementById('err').innerHTML ='';   
    let myModal = new bootstrap.Modal(document.getElementById('Modaledit')); 
    document.querySelector('#zagolovok').innerHTML= "Изменение записи" ;
    document.getElementById('ed').innerHTML ='Запись изменена!'; 
    let myToast = new bootstrap.Toast(document.getElementById('uved'));  
    document.getElementById('spiner').innerHTML ='Изменить';  
    document.getElementById('stat').classList.remove('inzer');
    document.getElementById('content').classList.remove('conte');
    document.getElementById('cotent_footer').classList.remove('conte_footer');
    fetch('../../fun/edit.php?id='+id+ '&razdel='+ razdel)
    .then(data=>{
        return data.text();
     })
     .then(data=>{
        let info = JSON.parse(data);  
        //console.log(info);       
          document.getElementById('date_edit').value = info.date;
          document.getElementById('nomer_edit').value = info.nomer;
          document.getElementById('status_edit').value = info.pod;
          document.getElementById('npa_edit').value = info.npa;
          document.getElementById('control_edit').value = info.control;
          document.getElementById('title_edit').value = info.title;
          document.getElementById('coment_edit').value = info.coment;
          document.getElementById('prim_edit').value = info.prim;
          document.getElementById('file').value = info.file;
          document.getElementById('id_zapisi').value = info.id;
          document.getElementById('id_here').value = id;
          edit_status(id,razdel);
     })
    myModal.show();
    
    
    document.getElementById("spiner").onclick=function(e){
        e.preventDefault();
        let form = document.getElementById('insert_form');
        let data = new FormData(form);
        fetch('../../fun/edit.php', {
            method: 'POST',
            body: data
         })         
         .then(data=>{     
            return data.text();   
             })   
            myModal.hide();
            var razdel = getUrlVars()["razdel"];
            var year = getUrlVars()["year"];
            var mon = getUrlVars()["mon"];  
            setTimeout(() => {           
            pa(razdel,year,mon);
            }, 500);
            myToast.show();
       
    };
}
/* -----------------/Изменение записи--------------------------- */

/* -------------Удаление записи---------------------- */
function delit( razdel_id,id){ 
    let myModal = new bootstrap.Modal(document.getElementById('Modaldelit')); 
    let myToas = new bootstrap.Toast(document.getElementById('dell'));  
    var razdel = getUrlVars()["razdel"];
    var year = getUrlVars()["year"];
    var mon = getUrlVars()["mon"];
    myModal.show();
    document.getElementById("del").onclick=function(){
    fetch('../../fun/delete_pa.php', {
        method: 'POST',       
        body:JSON.stringify({razdel:razdel_id, id:id })       
        })
        .then(data=>{
            return data.text();            
         })     
         myModal.hide(); 
         setTimeout(() => {                     
         pa(razdel,year,mon);
        }, 500);
        myToas.show();
        };
}

/* -------------/Удаление записи---------------------- */

/* -------------Добавление записи---------------------- */
function inzert(){     
    document.getElementById('insert_form').reset();
    document.querySelector('#zagolovok').innerHTML= "Добавить запись" ;
    document.getElementById('ed').innerHTML ='Запись добавлена!'; 
    let myModal = new bootstrap.Modal(document.getElementById('Modaledit'));  
    let myToast = new bootstrap.Toast(document.getElementById('uved'));     
    document.getElementById('stat').classList.add('inzer');
    document.getElementById('content').classList.add('conte');
    document.getElementById('cotent_footer').classList.add('conte_footer');  
    document.getElementById('spiner').innerHTML ='Сохранить';    
    myModal.show();
    document.getElementById("spiner").onclick=function(e){
        e.preventDefault();
        let form = document.getElementById('insert_form');
        let data = new FormData(form);
        fetch('../../fun/inzert.php', {
            method: 'POST',
            body: data
         })         
         .then(data=>{           
            myModal.hide(); 
            var razdel = getUrlVars()["razdel"];
            var year = getUrlVars()["year"];
            var mon = getUrlVars()["mon"];            
            pa(razdel,year,mon);
            myToast.show();
        })
    };
}
/* -------------/Добавление записи---------------------- */


/*----------------Меняем в поиске тип инпута---------------------*/
document.addEventListener('DOMContentLoaded', function(){   
    select.addEventListener("change",  function(){
        if(select.value == '3') {
        document.getElementById('hybrid').type = 'date';  }  }); 
     select.addEventListener("change",  function(){
        if(select.value == '1' ) {
        document.getElementById('hybrid').type = 'text';  }  });
     select.addEventListener("change",  function(){
        if(select.value == '2' ) {
        document.getElementById('hybrid').type = 'text';  }  });
});
/*--------------------/Меняем в поиске тип инпута----------------*/

/*----------------Индикатор закрузки---------------------*/
document.getElementById("spiner").addEventListener("click",function () {
    let numm = document.getElementById('nomer_edit');
    let date = document.getElementById('date_edit');
    let ann = document.getElementById('title_edit');
    if(numm, date, ann.value !== ''){
    this.innerHTML ='<span class="spinner-border spinner-border-sm" ></span> Загрузка... ';
}});
/*----------------/Индикатор закрузки---------------------*/