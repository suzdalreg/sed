const d = new Date();
const m = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
const year = d.getFullYear();
const month = d.getMonth();

const mon = m[d.getMonth()];
document.getElementById("y").textContent = year;
document.getElementById("m").textContent = mon;
const sec = Date.parse(d);
const today = new Date(sec).toISOString().substring(0,10);

const bsOffcanvas = new bootstrap.Offcanvas(document.getElementById('offcanvasRight')); 
const sName = document.getElementById("sesName").value


/* -------------Загрузка инфы---------------------- */
  let fToday = false;
  let fUprok = false; 
  let fSel = false;
  let arg = false;
  let fperehod = false;
  let fchec = false;
  let _select;
  let _data;
  let glavn;
  
   
function loadInf(select,data,mesj,god,glavn){        
    let arg1 = (arg) ? '&arg=1' : '';  
    let arg2 = (fToday) ? '&today=1' : '';
    let arg3 = (fUprok) ? '&uprok=1' : ''; 
    let arg4 = (fSel) ? '&sea=1&select='+select+'&data='+data : '';
    let arg5 = (fperehod) ? '&per=1&mes='+mesj+'&god='+god : '';
    let arg6 = (fchec) ? '&isp='+glavn : '';
    let tbody = document.getElementById('tbody'); 
    let el = document.getElementById("loader23");  
    el.style.display=   'block'; 
      fetch('fun/load/info.php?year='+ year+'&mon='+month +'&sesion='+sName+ arg1+ arg2+ arg3+arg4+arg5+arg6)
    .then(data=>{
       return data.text();
    })
    .then(data=>{        
        tbody.innerHTML = data;
       el.style.display= 'none';          
    })
    }
/* -------------/Загрузка инфы---------------------- */
/* -------------Поиск по не закрытым---------------------- */
document.getElementById("glav").onclick=function(){    
    glavn = document.getElementById('glavn').value;
    document.getElementById('btm_in').type='hidden';
    document.getElementById("pereh").textContent = 'Не закрытые записи: '+ glavn ;
    document.getElementById('xl').type='button';  
    fToday = false;
    fUprok = false;  
    arg = false; 
    fperehod = false;
    fSel = false;
    fchec = !fchec; 
    loadInf( '','','','',glavn);
    bsOffcanvas.hide(); 
}


/* -------------Поиск по не закрытым---------------------- */

/* -------------Переход---------------------- */
let mesj;
let god;
function perehod(mo,yard){
    bsOffcanvas.hide(); 
    document.getElementById('btm_in').type='hidden';
    document.getElementById("pereh").textContent = m[mo]+' '+yard;
     mesj = mo;
     god = yard;   
    fToday = false;
    fUprok = false;  
    arg = false;
    fSel = false;
    fchec = false;
    fperehod = !fperehod; 
    loadInf('s','d',mesj,god);
}
/* -------------Переход---------------------- */


/* -------------Поиск---------------------- */
document.getElementById("search").onclick=function(){ 
document.getElementById('btm_in').type='hidden';
_select = document.getElementById('select').value;
_data = document.getElementById('hybrid').value;
document.getElementById("pereh").textContent = 'Поиск';
fToday = false;
fUprok = false;  
arg = false;
fchec = false;
 fSel = !fSel; 
 loadInf(_select,_data);
 bsOffcanvas.hide(); 
 }

document.getElementById("hybrid").addEventListener("keydown", function (e) {
    if (e.keyCode == 13) {
document.getElementById('btm_in').type='hidden';
_select = document.getElementById('select').value;
_data = document.getElementById('hybrid').value;
document.getElementById("pereh").textContent = 'Поиск';
fToday = false;
fUprok = false;  
arg = false;
fchec = false;
 fSel = !fSel; 
 loadInf(_select,_data);
 bsOffcanvas.hide();

    }
});
/* -------------Поиск---------------------- */

/* -------------Сайт бар---------------------- */
function saitbar(){   
    document.getElementById("pereh").textContent ='';
    document.getElementById('xl').type='hidden'; 
    fchec = false;
    fToday = false;
    fSel = false
    fUprok = false;
    fperehod = false;
fetch('fun/search.php?date='+today+'&razdel=date' )
  .then(data=>{
    return data.text();            
   }) 
   .then(data=>{  
    let info = JSON.parse(data); 
    document.getElementById('tod').innerHTML = info[0]; 
    document.getElementById('upre').innerHTML = info[1];   
     bsOffcanvas.show();   
 document.getElementById("todays").onclick=function(){    
        document.getElementById('btm_in').type='hidden'; 
        document.getElementById("pereh").textContent = 'Сегодня';
        fToday = !fToday;  
        fSel = false;  
        fUprok = false;  
        arg = false;  
        loadInf();
        bsOffcanvas.hide();   
     }
 document.getElementById("upr").onclick=function(){  
        document.getElementById('btm_in').type='hidden';
        document.getElementById("pereh").textContent = 'Упреждающие';
        fToday = false;
        fSel = false;
        fUprok = !fUprok;
        arg = false;
        loadInf();
        bsOffcanvas.hide();        
     }    
})
}
/* -------------Сайт бар---------------------- */

/* -------------вывод списка файлов---------------------- */
function fileView(id){  
let fileList = document.getElementById('file-list'); 
let List = document.getElementById('list'); 
  fetch('fun/load/fileList.php?id='+id+ '&year='+ year+ '&mon='+month)
.then(data=>{
   return data.text();
})
.then(data=>{        
    fileList.innerHTML = data;
    List.innerHTML = data;    
})
}

/* -------------/вывод списка файлов---------------------- */

/* -------------Вывод исполнителей---------------------- */
function show_isp(id) {
    let tbody = document.getElementById('ispol'); 
      fetch('fun/load/isp.php?id='+ id)
    .then(data=>{
       return data.text();
    })
    .then(data=>{        
        tbody.innerHTML = data;        
    })   
}
/* -------------Вывод исполнителей---------------------- */

/* -------------Добавление исполнителя---------------------- */
function add_isp(){
let id  = document.getElementById('id_info').value;
let form = document.getElementById('isp_form');
let data = new FormData(form);
fetch('/fun/inzert.php', {
    method: 'POST',
    body: data
  })
  .then(data=>{
    return data.text();            
   }) 
   .then(data=>{   
    if (data =='add') {
        form.reset();  
        show_isp(id);
    }          
})
}
/* -------------Добавление исполнителя---------------------- */

/* -------------Изменение записи ---------------------- */
let eModal;
let eModald;
let eToast;
     document.getElementById("spiner_edit").onclick=function(){
        
        let form = document.getElementById('edit_form');
        let data = new FormData(form);       
        fetch('/fun/inzert.php', {
            method: 'POST',
            body: data
          })
          .then(data=>{
            return data.text();            
           }) 
           .then(data=>{   
            if (data =='up') {
                if (eModal) { eModal.hide(); }
                if (eToast) { eToast.show(); }
                loadInf(_select,_data,mesj,god,glavn);                
            }          
        })
     }   

function edit_info(id){
   // e = window.event.path[2];
   // e.classList.add('active'); 
    document.getElementById('edit_form').reset();  
    let myModal = new bootstrap.Modal(document.getElementById('Modaledit'));  
    let myToas = new bootstrap.Toast(document.getElementById('uved'));   
    eModal = myModal;
    eToast = myToas;
    fetch('fun/edit.php?id='+id+ '&razdel=load_edit')
    .then(data=>{
        return data.text();
     })
     .then(data=>{
        let info = JSON.parse(data); 
        show_isp(id);              
          document.getElementById('nomer_isx_edit').value = info.out_num; 
          document.getElementById('date_isx_edit').value = info.out_date; 
          document.getElementById('nomer_vx_edit').value = info.in_nomer; 
          document.getElementById('date_vx_edit').value = info.in_date; 
          document.getElementById('vid_edit').value = info.vid_doc; 
          document.getElementById('otdel').value = info.otdel; 
          document.getElementById('control_ed').value = info.srok; 
          document.getElementById('title').value = info.title;
          document.getElementById('exampleDataList').value = info.org;  
          document.getElementById('exampleDataList1').value = info.nomenklatura; 
          document.getElementById('id_new_edit').value = info.id;       
          document.getElementById('id_info').value = info.id;    
          document.getElementById('report').value = info.report;       
          myModal.show(); 
          
     })       
     }
/* -------------/Изменение записи---------------------- */ 
     
/* -------------Изменение главного исполнителя---------------------- */ 
function ch(id_ch) {
    let id_info = document.getElementById('id_info').value ;       
        fetch('fun/isp_gl.php?id='+id_ch+'&id_info='+id_info)
        .then(data=>{
            return data.text();
         }) 
         .then(data=>{  
         if (data =='ok') {              
            show_isp(id_info);
        }  
    })     

}
/* -------------Изменение главного исполнителя---------------------- */ 
function clearSelection(el){ //to clear dropdown dselect upon close or submit 
    dselectClear(el.nextElementSibling.querySelector('button'), 'dselect-wrapper');
  }
/* -------------Добавление записи---------------------- */
function inzert(){         
    document.getElementById('insert_form').reset(); 
    $("#stock_item").html("");
    let butt=document.querySelectorAll('.form-select');
    console.log(butt);
    //dselectClear(butt,'form-select'); 
    document.querySelector('input[type=file]').value = '';
     document.getElementById('file-list').innerHTML = ''; 
    let title = document.getElementById("nomer_edit"); 
    let myModal = new bootstrap.Modal(document.getElementById('Modalin'));  
    let myToast = new bootstrap.Toast(document.getElementById('uved')); 
    let pusto = new bootstrap.Toast(document.getElementById('pusto'));  
    document.getElementById('year-hid').value = year;    
    fetch('fun/inzert.php', {
        method: 'POST',       
        body:JSON.stringify({fun:'inzert', year:year, mon:month  })       
        })
        .then(data=>{
            return data.text();            
         })     
         .then(data=>{            
            if (data !=='') {
                document.getElementById('id_new').value = data;                
               myModal.show();              
            }
        }) 
     document.getElementById("spiner").onclick=function(e){
        e.preventDefault();
        let form = document.getElementById('insert_form');        
        let data = new FormData(form);
        if(!title.value.trim().length){
            pusto.show();           
        }else{
        fetch('fun/inzert.php', {
            method: 'POST',
            body: data
         })     
         .then(data=>{
            return data.text();            
         })         
         .then(data=>{   
            if (data =='ok') {
                myModal.hide();            
                myToast.show();
                loadInf();
            }          
        })
        }
    }; 

let file = document.getElementById('file')
file.onchange = function (e) { 
    e.preventDefault()    
    let el = document.getElementById("loader");  
    el.style.display=   'block'; 
    let files = e.target.files;      
    let id = e.target.form[7].defaultValue;
    let  formData = new FormData();
    for(let key in files){
    formData.append(key, files[key]);
    }       
    formData.append('year', year);
    formData.append('id', id);
    formData.append('mon', month);
     fetch('fun/upload.php', {
        method: "POST",
        body: formData
    })
        .then(data=> {
            return data.text();            
         })         
         .then(data=>{   
            if (data =='ok') {
                el.style.display= 'none';
               fileView(id);          
               document.querySelector('input[type=file]').value = '';
            }          
        })
  };
}

/* -------------/Добавление записи---------------------- */

/* -------------Удаление файла---------------------- */
function del_file(id_file, id_zapisi){ 
//console.log(id_file, id_zapisi);
let Modal = new bootstrap.Modal(document.getElementById('del_f')); 
Modal.show();
document.getElementById("del_btm_f").onclick=function(){
    fetch('/fun/del.php', {
        method: 'POST',       
        body:JSON.stringify({org:'delf', id_file:id_file,id_zapisi:id_zapisi,year:year })       
        })
        .then(data=>{
            return data.text();            
         })
         .then(data=>{  
            if (data =='del_file') {
                Modal.hide();               
                fileView(id_zapisi);  
            }
         })  
        };
}
/* -------------Удаление файла---------------------- */
/* -------------Удаление Записи---------------------- */
let iddel;
    document.getElementById("del_btm").onclick=function(){

        fetch('/fun/del.php', {
            method: 'POST',       
            body:JSON.stringify({org:'del_info', id:iddel})       
            })
            .then(data=>{
                return data.text();            
             })
             .then(data=>{  
                if (data =='del_info') {
                   // e.classList.remove('active');  
                    if (eModald) { eModald.hide(); }                                  
                    loadInf(_select,_data,mesj,god,glavn);  
                }
             })  
            };

function del_info(id){ 
    let myModaldel = new bootstrap.Modal(document.getElementById('del_inf')); 
    iddel = id;
    eModald = myModaldel;
    //e = window.event.path[2];
    //e.classList.add('active');
    myModaldel.show();

    }
/* -------------Удаление записи---------------------- */

/* -------------Удаление исплнителя---------------------- */
function del_isp(id) {
    let id_info = document.getElementById('id_info').value ;  
        fetch('fun/del.php?id='+id+'&info=del_isp')
        .then(data=>{
            return data.text();
         }) 
         .then(data=>{  
         if (data =='ok') {              
            show_isp(id_info);
        }  
    })     

}
/* -------------Удаление исплнителя---------------------- */

/* -------------Работа с файлами---------------------- */
function view_file(id){    
    //e = window.event.path[2];
    //e.classList.add('active');  
    
    let myModalf = new bootstrap.Modal(document.getElementById('Modalfile')); 
    let file = document.getElementById('fileup');    
    fileView(id); 
    myModalf.show();
    file.onchange = function(e) { 
        e.preventDefault()    
        let el = document.getElementById("loader2");  
        el.style.display=   'block'; 
        let files = e.target.files;     
        let  formData = new FormData();
        for(let key in files){
        formData.append(key, files[key]);
        }       
        formData.append('year', year);
        formData.append('id', id);
        formData.append('mon', month);
         fetch('fun/upload.php', {
            method: "POST",
            body: formData
        })
            .then(data=> {
                return data.text();            
             })         
             .then(data=>{   
                if (data =='ok') {
                   el.style.display= 'none';
                   fileView(id);          
                   document.getElementById('fileup').value = '';
                }          
            })           
      };
}
/* -------------Работа с файлами---------------------- */

/* -------------Удаление класса со строки---------------------- */
 document.getElementById("fileclos").onclick=()=>{                
               // e.classList.remove('active');  
            };
document.getElementById("del_inf").onclick=()=>{                
              //  e.classList.remove('active');  
            };       
document.getElementById("clos_edit").onclick=()=>{                
               // e.classList.remove('active');  
            };                
/* -------------Удаление класса со строки---------------------- */

/* -------------Удаление по закрытию---------------------- */
document.getElementById("clos").onclick=()=>{
 let id = document.getElementById('id_new').value;
 fetch('/fun/del.php', {
    method: 'POST',       
        body:JSON.stringify({org:'delzap', id:id,year:year })       
        })
        .then(data=>{
            return data.text();            
         })
};
/* -------------Удаление по закрытию---------------------- */

/*----------------Меняем в поиске тип инпута---------------------*/
document.addEventListener('DOMContentLoaded', function(){   
    select.addEventListener("change",  function(){
        if(select.value == 'srok') {
        document.getElementById('hybrid').type = 'date';  }  }); 
     select.addEventListener("change",  function(){
        if(select.value == 'an' ) {
        document.getElementById('hybrid').type = 'text';  }  });
     select.addEventListener("change",  function(){
        if(select.value == 'ix_n' ) {
        document.getElementById('hybrid').type = 'text';  }  });
    select.addEventListener("change",  function(){
         if(select.value == 'vx_n' ) {
            document.getElementById('hybrid').type = 'text';  }  });
    select.addEventListener("change",  function(){
        if(select.value == 'ix_d') {
                document.getElementById('hybrid').type = 'date';  }  });     
    select.addEventListener("change",  function(){
        if(select.value == 'vx_d') {
                document.getElementById('hybrid').type = 'date';  }  }); 
    select.addEventListener("change",  function(){
        if(select.value == 'org' ) {
                document.getElementById('hybrid').type = 'text';  }  });              
});
/*--------------------/Меняем в поиске тип инпута----------------*/

document.getElementById("xl").onclick=function(){ 
    window.open('src/exel/export.php?isp='+glavn);
   /*  fetch('src/exel/export.php?isp='+glavn )
  .then(data=>{
    return data.text();            
   }) */ 
}
