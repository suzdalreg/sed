 /* -------------------загрузда данных по организациям--------------------------- */
function org() {	
    let tbody = document.getElementById("table_org");     
     fetch('fun/load/org.php')
     .then(data=>{
        return data.text();
     })
     .then(data=>{        
         tbody.innerHTML = data;       
     })
 }
 /* -------------------/загрузда данных по организациям--------------------------- */

  /* -------------------загрузка данных по исполнителям--------------------------- */
function person() {	
    let tbody = document.getElementById("table_person");     
     fetch('fun/load/person.php')
     .then(data=>{
        return data.text();
     })
     .then(data=>{        
         tbody.innerHTML = data;       
     })
 }
 /* -------------------/загрузка данных по исполнителям--------------------------- */

   /* -------------------загрузка нуменклатуры--------------------------- */
function numenklatura() {	
    let tbody = document.getElementById("table_nomenklatura");     
     fetch('fun/load/mumenklatura.php')
     .then(data=>{
        return data.text();
     })
     .then(data=>{        
         tbody.innerHTML = data;       
     })
 }
 /* -------------------/загрузка нуменклатуры--------------------------- */


 /* -------------Добавление организации---------------------- */ 
 document.getElementById("spiner_org").onclick=function(e){
    e.preventDefault();
    let title = document.getElementById("exampleDataList");
    let form = document.getElementById("insert_form_org");
    let myToast = new bootstrap.Toast(document.getElementById('uved'));    
    let pusto = new bootstrap.Toast(document.getElementById('pusto'));  
    let data = new FormData(form);
    //console.log(title);
    if(!title.value.trim().length){
        pusto.show();
    }else{
    fetch('../../fun/inzert.php', {
        method: 'POST',
        body: data
     })         
     .then(data=>{     
        return data.text();   
         })   
         .then(data=>{            
            if (data =='org') {
                myToast.show();
                form.reset();
                org();
            }
 })   
}
}
/* -------------/Добавление организации---------------------- */

/* -------------Добавление исполнителя---------------------- */
 
document.getElementById("spiner_person").onclick=function(e){
    e.preventDefault();
    //let forma = document.forms.insert_form_person;   
    let form = document.getElementById("insert_form_person");
    let title = form.elements.person.value;
    let myToast = new bootstrap.Toast(document.getElementById('uved'));    
    let pusto = new bootstrap.Toast(document.getElementById('pusto'));  
    let data = new FormData(form);   
   // console.log(data); 
    if(!title.trim().length){
        pusto.show();
    }else{
    fetch('../../fun/inzert.php', {
        method: 'POST',
        body: data
     })         
     .then(data=>{     
        return data.text();   
         })   
         .then(data=>{            
            if (data =='person') {
                myToast.show();
                form.reset();
                person();
            }
 })   
}
}
/* -------------/Добавление исполнителя---------------------- */



 /* -------------Добавление номенклатуры---------------------- */ 
 document.getElementById("spiner_num").onclick=function(e){
    e.preventDefault();
    let title = document.getElementById("numenk");
    let form = document.getElementById("insert_form_num");
    let myToast = new bootstrap.Toast(document.getElementById('uved'));    
    let pusto = new bootstrap.Toast(document.getElementById('pusto'));  
    let data = new FormData(form);    
    if(!title.value.trim().length){
        pusto.show();
    }else{
    fetch('../../fun/inzert.php', {
        method: 'POST',
        body: data
     })         
     .then(data=>{     
        return data.text();   
         })   
         .then(data=>{            
            if (data =='num') {
                myToast.show();
                form.reset();
                numenklatura();
            }
 })   
}
}
/* -------------/Добавление  номенклатуры---------------------- */
 

/* -------------Удаление ---------------------- */
function del_org(razdel,id){ 
    let myModal = new bootstrap.Modal(document.getElementById('Modal_del_org')); 
    let myToas = new bootstrap.Toast(document.getElementById('dell')); 
    //console.log(org);     
    myModal.show();
    document.getElementById("del_org").onclick=function(){
    fetch('../../fun/del.php', {
        method: 'POST',       
        body:JSON.stringify({org:razdel, id:id })       
        })
        .then(data=>{
            return data.text();            
         })     
         .then(data=>{            
            if (data =='del_org') {
                myModal.hide();          
                myToas.show();
                org();
            }
            if (data =='del_person') {
                myModal.hide();          
                myToas.show();
                person();
            }
            if (data =='del_num') {
                myModal.hide();          
                myToas.show();
                numenklatura();
            }
 })            
        };
}
/* -------------/Удаление ---------------------- */
/* -------------Изменение  в справочнике---------------------- */
function edit_org(razdel,id){ 
    let myModal = new bootstrap.Modal(document.getElementById('edit')); 
    let myToas = new bootstrap.Toast(document.getElementById('uved'));   
    fetch('../../fun/edit.php?id='+id+ '&razdel='+ razdel)
    .then(data=>{
        return data.text();
     })
     .then(data=>{
        let info = JSON.parse(data);               
          document.getElementById('org_view').value = info.value; 
          document.getElementById('id_edit').value = info.id; 
          document.getElementById('razdel_edit').value = razdel;       
     })       
    myModal.show();
    document.getElementById("edit_spravka").onclick=function(){
        let form = document.getElementById('form_edit');
        let data = new FormData(form);
    fetch('../../fun/edit.php', {
        method: 'POST',       
        body:data       
        })
        .then(data=>{
            return data.text();            
         })     
         .then(data=>{            
            if (data =='ok') {
                myModal.hide();          
                myToas.show();
                org();
            }
            if (data =='oks') {
                myModal.hide();          
                myToas.show();
                numenklatura();
            }
 })            
        };
}
/* -------------/Изменение в справочнике---------------------- */