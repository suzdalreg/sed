<?php
include("../../setting.php");
include("../../path.php");
include("SimpleXLSXGen.php");
$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
if ($CONNECT == false) {
  print("Ошибка: Невозможно подключиться к MySQL " . mysqli_connect_error());
}
//tt($_GET);

$employees = [
  ['П/№', 'Рег.Дата', 'Рег.Номер', 'Организация', 'Аннотация', 'Срок', 'Исполнители']
];

$in = 0;

if ($_GET['isp'] == 'все') {
  //$sql = "SELECT * FROM `info` LEFT JOIN `user` ON id_info = info.id WHERE report = '' GROUP BY info.in_nomer  ORDER BY `regdate` DESC";
  //$sql = "SELECT * FROM `info` LEFT JOIN `user` ON id_info = info.id WHERE report = '' AND user.otv ='checked' HAVING user.otv ='checked'";
  $sql = "SELECT * FROM `user` INNER JOIN `info` ON id_info = info.id WHERE info.report = '' AND user.otv ='checked'  ORDER BY `regdate` DESC";
}
if ($_GET['isp'] == 'пустые') {
  $sql =  "SELECT * FROM `info` LEFT JOIN `user` ON id_info = info.id WHERE user.ispolnitel IS NULL AND info.report=''";
  //echo 'пусто';
}




if (!empty($_GET['isp']) && ($_GET['isp'] !== "все") && ($_GET['isp'] !== "пустые")) {
  $sql = "SELECT * FROM `user` INNER JOIN `info` ON id_info = info.id WHERE info.report = '' AND user.otv ='checked' AND user.ispolnitel = '$_GET[isp]' ORDER BY `regdate` DESC ";
}
$res = mysqli_query($CONNECT, $sql);

if (mysqli_num_rows($res) > 0) {
  foreach ($res as $row) {
    $qwery = mysqli_query($CONNECT, "SELECT * FROM `user` WHERE `id_info` = '{$row['id']}' ORDER BY `user`.`otv` DESC");
    if (mysqli_num_rows($qwery) > 0) {
      foreach ($qwery as $ro) {
        tt($ro);
      }
    }
    //tt($row);
    $in++;

    $employees = array_merge($employees, array(array($in, $row['in_date'], $row['in_nomer'], $row['org'], $row['title'], $row['srok'], $row['ispolnitel'])));
  }
}

$xlsx = SimpleXLSXGen::fromArray($employees);
$xlsx->downloadAs('Выгрузка.xlsx'); 
  // $xlsx->saveAs('employees.xlsx');
  //echo "<pre>";
  //print_r($employees);
