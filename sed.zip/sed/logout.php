<?php
session_start();

include "path.php";

unset($_SESSION['USER_NAME']);
unset($_SESSION['USER_LOGIN_IN']);
unset($_SESSION['USER_tip']);
unset($_SESSION['NAME']);



header('location: ' . BASE_URL);
