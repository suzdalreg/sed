<?php
session_start();
const SITE_ROOT = __DIR__;
const BASE_URL = "http://192.168.0.4/";
define("ROOT_PATH", realpath(dirname(__FILE__)));


function category($p1)
{

	if ($p1 == 1) return ' Постановления администрации района';
	else if ($p1 == 2) return 'Постановления Главы Суздальского района';
	else if ($p1 == 3) return 'Распоряжения администрации района';
	else if ($p1 == 4) return 'Распоряжения Главы Суздальского района';
	else if ($p1 == 5) return 'Решения Cовета народных депутатов';
	else if ($p1 == 6) return 'Распоряжения по личному составу';
	else if ($p1 == 7) return 'НПА АВО';
}

function npa($p1)
{

	if ($p1 == 1) return ' Да';
	else if ($p1 == 2) return 'Нет';
}

function status($p1)
{

	//if ($p1 == 0) return '-';
	if ($p1 == 1) return 'Внесены изменения';
	else if ($p1 == 2) return 'Утратил силу';
	else if ($p1 == 3) return 'Отменено';
}

function month($p1)
{

	if ($p1 == 1) return ' Январь';
	else if ($p1 == 2) return 'Февраль';
	else if ($p1 == 3) return 'Март';
	else if ($p1 == 4) return 'Апрель';
	else if ($p1 == 5) return 'Май';
	else if ($p1 == 6) return 'Июнь';
	else if ($p1 == 7) return 'Июль';
	else if ($p1 == 8) return 'Август';
	else if ($p1 == 9) return 'Сентябрь';
	else if ($p1 == 10) return 'Октябрь';
	else if ($p1 == 11) return 'Ноябрь';
	else if ($p1 == 12) return 'Декабрь';
}

function stolb($p1)
{

	if ($p1 == 3) return ' Всего документов';
	else if ($p1 == 4) return 'Исполнено в срок';
	else if ($p1 == 5) return 'Просрочено';
	else if ($p1 == 6) return 'На исполнении';
	else if ($p1 == 7) return 'Выполнено с опозданием';
}

function convert_date($date)
{
	if (strlen(trim($date)) <= 0) return "";
	$str_exp = explode("-", $date);
	return $str_exp[2] . "." . $str_exp[1] . "." . $str_exp[0];
}

function translit_path($value)
{
	$converter = array(
		'а' => 'a',    'б' => 'b',    'в' => 'v',    'г' => 'g',    'д' => 'd',
		'е' => 'e',    'ё' => 'e',    'ж' => 'zh',   'з' => 'z',    'и' => 'i',
		'й' => 'y',    'к' => 'k',    'л' => 'l',    'м' => 'm',    'н' => 'n',
		'о' => 'o',    'п' => 'p',    'р' => 'r',    'с' => 's',    'т' => 't',
		'у' => 'u',    'ф' => 'f',    'х' => 'h',    'ц' => 'c',    'ч' => 'ch',
		'ш' => 'sh',   'щ' => 'sch',  'ь' => '',     'ы' => 'y',    'ъ' => '',
		'э' => 'e',    'ю' => 'yu',   'я' => 'ya',

		'А' => 'A',    'Б' => 'B',    'В' => 'V',    'Г' => 'G',    'Д' => 'D',
		'Е' => 'E',    'Ё' => 'E',    'Ж' => 'Zh',   'З' => 'Z',    'И' => 'I',
		'Й' => 'Y',    'К' => 'K',    'Л' => 'L',    'М' => 'M',    'Н' => 'N',
		'О' => 'O',    'П' => 'P',    'Р' => 'R',    'С' => 'S',    'Т' => 'T',
		'У' => 'U',    'Ф' => 'F',    'Х' => 'H',    'Ц' => 'C',    'Ч' => 'Ch',
		'Ш' => 'Sh',   'Щ' => 'Sch',  'Ь' => '',     'Ы' => 'Y',    'Ъ' => '',
		'Э' => 'E',    'Ю' => 'Yu',   'Я' => 'Ya',
	);

	$value = mb_strtolower($value);
	$value = strtr($value, $converter);
	$value = mb_ereg_replace('[^-0-9a-z\.]', '-', $value);
	$value = mb_ereg_replace('[-]+', '-', $value);
	$value = trim($value, '-');

	return $value;
}

function traslit_url($url)
{
	$url = parse_url(trim($url));
	if (!empty($url['host'])) {
		$res = '';
		if (!empty($url['scheme'])) {
			$res .= $url['scheme'] . '://';
		}
		if (!empty($url['host'])) {
			$res .= idn_to_ascii($url['host']);
		}
		if (!empty($url['port'])) {
			$res .= ':' . $url['port'];
		}
		if (!empty($url['path'])) {
			$path = explode('/', $url['path']);
			foreach ($path as $i => $row) {
				if (preg_match('/[а-яё]/iu', $row)) {
					$path[$i] = translit_path($row);
				}
			}

			$res .= implode('/', $path);
		}
		if (!empty($url['query'])) {
			$res .= '?' . $url['query'];
		}
		if (!empty($url['fragment'])) {
			$res .= '#' . $url['fragment'];
		}

		return $res;
	} else {
		return translit_path($url);
	}
}


function tt($value)
{
	echo '<pre>';
	print_r($value);
	echo '</pre>';
}
