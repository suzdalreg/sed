﻿<?php
session_start();
include_once 'setting.php';

$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
include("path.php");
?>
<!doctype html>
<html lang="ru">

<head>
  <!-- Required meta tags -->

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="src/css/bootstrap.min.css">
  <link rel="stylesheet" href="src/css/style.css">

  <title>Поиск не закрытых</title>
</head>

<body>
  <?php include("app/include/header.php"); ?>

  <div class="container-fluid">
    <div class="content row">
      <?php
      //tt($_POST);
      if (isset($_POST['vse']) && $_POST['vse'] == 'Yes') {
      } else {
      }




      ?>

    </div>
  </div>
  <?php include("app/include/footer.php"); ?>






</body>

</html>