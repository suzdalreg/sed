﻿<?php
session_start();
include_once 'setting.php';

$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
include("path.php");
?>
<!doctype html>
<html lang="ru">

<head>
  <!-- Required meta tags -->

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="src/css/bootstrap.min.css">
  <link rel="stylesheet" href="src/css/style.css">

  <title>Справочник</title>
</head>

<body>
  <?php include("app/include/header.php"); ?>

  <div class="container-fluid">
    <div class="content row">
      <!-- Main Content -->
      <div class="user col-md-12 ">
        <!-- Хлебные крошки-->
        <nav aria-label="breadcrumb" style="margin-top: 10px;">
          <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">Справочник</li>
          </ol>
        </nav>
        <!--Конец- Хлебные крошки-->

      </div>

      <div class="person col-md-2 " id="person" class="person">
        <H4>Исполнители </H4>
        <div class="year">
          <form method="POST" action="" id="insert_form_person" enctype="multipart/form-data">
            <div class="row">
              <div class="col">
                <input type="hidden" name="tip" value="person">
                <input type="text" name="person" id="person" class="form-control" style=" font-size:13px; width:140px;" autocomplete="off" placeholder="Ф.И.О">
              </div>
              <div class="col">
                <button type="submit" name="pers" id="spiner_person" class="btn btn-success" style=" font-size:13px;">Добавить </button>
              </div>
            </div>
          </form>
          <div class="scrol_person">
            <table class="table table-hover sprav" id="table_person">
            </table>
          </div>
        </div>
      </div>

      <div class="org col-md-5 " id="org" class="organizacii">
        <H4>Организации </H4>
        <div class="year">
          <form method="POST" action="" id="insert_form_org" enctype="multipart/form-data">

            <div class="row">
              <div class="col">
                <input type="hidden" name="tip" value="organ">
                <!-- <textarea name="title" class="form-control z-depth-1" style="width: 400px; " id="organ" rows="4" required placeholder="Название"></textarea> -->
                <input class="form-control form-control-sm" name="title" style="width: 400px; " list="orgi" name="organ" id="exampleDataList">
                <datalist id="orgi">
                  <?php
                  $sel = mysqli_query($CONNECT, "SELECT * FROM `org` ORDER BY `org`.`value` ASC");
                  $org = mysqli_fetch_all($sel);
                  foreach ($org as  $lib) {
                    //tt($lib);
                    echo '
                        <option value="' . $lib[1] . '">' . $lib[1] . '</option>
                        ';
                  }
                  ?>
                </datalist>

              </div>
              <div class="col">
                <button type="submit" id="spiner_org" class="btn btn-success" style=" font-size:14px;">Добавить </button>
              </div>
            </div>
          </form>


          <div class="scrol">
            <table class="table table-hover sprav" id="table_org">
            </table>
          </div>
        </div>
      </div>

      <div class="num col-md-4 " id="num">
        <H4>Номенклатура </H4>
        <div class="year">
          <form method="POST" action="" id="insert_form_num" enctype="multipart/form-data">
            <div class="row">
              <div class="col">
                <input type="hidden" name="tip" value="numenklatura">
                <textarea name="title_num" class="form-control z-depth-1" style="width: 300px;" id="numenk" rows="4" required placeholder="Название"></textarea>
              </div>
              <div class="col">
                <button type="submit" id="spiner_num" class="btn btn-success" style=" font-size:14px;">Добавить </button>
              </div>
            </div>
          </form>
          <div class="scrol">
            <table class="table table-hover sprav" id="table_nomenklatura">
            </table>
          </div>
        </div>
      </div>

    </div>
  </div>




  <?php include("app/include/footer.php"); ?>
  <!-- Modal для удаления-->
  <div class="modal fade" id="Modal_del_org" tabindex="-1" aria-labelledby="exampleModalLabel12" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Внимание!</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Вы действительно хотите удалить запись ?
        </div>
        <div class="modal-footer">
          <input type="submit" style="width: 100px;" value="Удалить" class="btn btn-danger  god " id="del_org">
        </div>
      </div>
    </div>
  </div> <br>
  <!-- Modal конец -->
  <!-- Modal изменения -->
  <div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel12" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="ip"> Изменение записи </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="form_edit">
            <input type="hidden" name="id" id="id_edit">
            <input type="hidden" name="razdel" class="cat" id="razdel_edit">
            <textarea name="title" class="form-control z-depth-1" id="org_view" rows="4"></textarea>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" id="edit_spravka">Изменить</button>

        </div>
      </div>
    </div>
  </div>
  <!-- Modal изменения конец -->
  <!-- Уведомление -->
  <div class="toast" id="uved" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="2000" style="display:block;position:fixed; bottom:90%;right:50%; text-align: center; font-size: 17px;">
    <div class="toast-body " id="ed" style=" background-color: rgb(140, 221, 147);">
      Выполнено успешно!
    </div>
  </div>
  <!-- Уведомление конец -->

  <!-- Уведомление удаления-->
  <div class="toast" id="dell" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="2000" style="display:block;position:fixed; bottom:90%;right:50%; text-align: center; font-size: 17px;">
    <div class="toast-body" style=" background-color: rgb(207, 136, 136);">
      Запись удалена!
    </div>
  </div>
  <!-- конец удаления -->
  <!-- Уведомление пусто-->
  <div class="toast" id="pusto" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="2000" style="display:block;position:fixed; bottom:90%;right:50%; text-align: center; font-size: 17px;">
    <div class="toast-body" style=" background-color:#34adb3;">
      Заполните поле!
    </div>
  </div>
  <!-- конец  -->

  <script src="src/js/bootstrap.min.js"></script>
  <script src="src/js/spravka.js"></script>
  <script>
    org();
    person();
    numenklatura();
  </script>
</body>

</html>