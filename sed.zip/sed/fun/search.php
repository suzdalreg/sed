﻿<?php include_once '../setting.php';
$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
include("../path.php");
//tt($_GET);
if ($_GET['razdel'] == 'date') {
  $date = new DateTime();
  $date->modify('+5 day');
  $data = $date->format('Y-m-d');

  $dat = new DateTime();
  $dat->modify('+ 1day');
  $dat = $dat->format('Y-m-d');
  //tt($data);
  $result = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `srok` = '$_GET[date]'  ");
  $line = mysqli_fetch_all($result);

  $re = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `srok` BETWEEN '$dat' AND '$data'  ");
  $l = mysqli_fetch_all($re);
  //tt($l);
  $n = count($line);
  $u = count($l);
  $resp = array("$n", "$u");
  // echo ($resp);
  echo json_encode($resp);
}
