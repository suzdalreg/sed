﻿<?php include_once '../setting.php';
include("../path.php");
$CONNECT = mysqli_connect(HOST, USER, PASS, DB);


$file = $_FILES;
foreach ($file as $file) {

    if (!is_dir('../file/' . $_POST[year] . '/' . $_POST[mon] . '/' . $_POST[id] . '')) {
        mkdir('../file/' . $_POST[year] . '/' . $_POST[mon] . '/' . $_POST[id] . '', 0777, true);
    }
    $tip = pathinfo($file["name"], PATHINFO_EXTENSION);
    $fileOriginalName = pathinfo($file["name"], PATHINFO_FILENAME) . ".$tip";
    $fileName = time() . ".$tip";

    if (!move_uploaded_file($file["tmp_name"], "../file/" . $_POST["year"] . '/' . $_POST["mon"] . '/' . $_POST["id"] . '/' .  $fileName)) {
        die('Error upload file');
    }
    mysqli_query($CONNECT, "INSERT INTO `file`  VALUES (NULL, '$_POST[id]','$fileOriginalName','$fileName')");


    sleep(1);
}
echo 'ok';
