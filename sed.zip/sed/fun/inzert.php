﻿<?php include_once '../setting.php';

$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
include("../path.php");
$mydata = json_decode(file_get_contents("php://input"), true);
//tt($_POST);
if ($_POST['tip'] == 'organ') {
  $res = mysqli_query($CONNECT, "INSERT INTO org  VALUES (NULL, '$_POST[title]')");
  if ($res == 1) {
    echo 'org';
  } else {
    echo 'Error';
  }
}
if ($_POST['tip'] == 'person') {
  $res = mysqli_query($CONNECT, "INSERT INTO person  VALUES (NULL, '$_POST[person]')");
  if ($res == 1) {
    echo 'person';
  } else {
    echo 'Error';
  }
}
if ($_POST['tip'] == 'numenklatura') {
  $res = mysqli_query($CONNECT, "INSERT INTO numeklatura  VALUES (NULL, '$_POST[title_num]')");
  if ($res == 1) {
    echo 'num';
  } else {
    echo 'Error';
  }
}
if ($mydata['fun'] == 'inzert') {
  //$res = mysqli_query($CONNECT, "INSERT INTO numeklatura  VALUES (NULL, '$_POST[title_num]')");
  mysqli_query($CONNECT, " INSERT INTO `info` VALUES (NULL, '$mydata[mon]','$mydata[year]',  '', '', '', '', '', '', '', '', '','', CURRENT_TIMESTAMP,'') ");
  $id = mysqli_insert_id($CONNECT);
  if ($id !== '') {
    echo "$id";
  } else {
    echo 'Error';
  }
}
if ($_POST['funс'] == 'in_info') {
  if (mysqli_query($CONNECT, "UPDATE `info` SET `out_num` = '$_POST[nomer_isx]', `out_date` = '$_POST[date_isx]', `in_nomer` = '$_POST[nomer_vx]', `in_date` = '$_POST[date_vx]',`vid_doc` = '$_POST[doc]',`org` = '$_POST[organ]',`title` = '$_POST[title]',`nomenklatura` = '$_POST[numorg]', `srok` = '$_POST[control]'  WHERE `$base`.`id` = '$_POST[id]'") === TRUE) {
    echo 'ok';
  } else {
    echo 'Ошибка';
  }
}
if ($_POST['tip'] == 'add') {
  $res = mysqli_query($CONNECT, "INSERT INTO `user`  VALUES (NULL, '$_POST[id]', '$_POST[avtor]', '$_POST[rezolut]',  '$_POST[date_rez]', '$_POST[ispolnitel]', '$_POST[date_per]', '', CURRENT_TIMESTAMP)");
  if ($res == 1) {
    echo 'add';
  } else {
    echo 'Error_add';
  }
}
if ($_POST['tip'] == 'up') {
  if (mysqli_query($CONNECT, "UPDATE `info` SET `out_num` = '$_POST[nomer_isx]', `out_date` = '$_POST[date_isx]', `in_nomer` = '$_POST[nomer_vx]', `in_date` = '$_POST[date_vx]',`vid_doc` = '$_POST[doc]',`org` = '$_POST[organ]',`title` = '$_POST[title]',`nomenklatura` = '$_POST[nomenklatura]', `srok` = '$_POST[control]' , `report` = '$_POST[report]', `otdel` = '$_POST[otdel]'  WHERE`id` = '$_POST[id]'") === TRUE) {
    echo 'up';
  } else {
    echo 'Ошибка_up';
  }
}
