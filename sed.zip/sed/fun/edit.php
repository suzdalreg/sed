﻿<?php include_once '../setting.php';
$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
include("../path.php");

$id = $_GET['id'];

//tt($_GET);
if ($_GET['razdel'] == 1) {
  $result = mysqli_query($CONNECT, "SELECT * FROM `org` WHERE `id` = $id  ");
  $resp = array();
  while ($line = mysqli_fetch_assoc($result)) {;
    $resp = $line;
    //tt($resp);
  }
  echo json_encode($resp);
}

if ($_GET['razdel'] == 3) {
  $result = mysqli_query($CONNECT, "SELECT * FROM `numeklatura` WHERE `id` = $id  ");
  $resp = array();
  while ($line = mysqli_fetch_assoc($result)) {;
    $resp = $line;
    //tt($resp);
  }
  echo json_encode($resp);
}

if ($_POST['razdel'] == 1) {

  if (mysqli_query($CONNECT, "UPDATE `org` SET `value` = '$_POST[title]' WHERE `org`.`id` = '$_POST[id]'") === TRUE) {
    printf("ok");
  } else {
    echo 'Ошибка';
  }
}
if ($_POST['razdel'] == 3) {

  if (mysqli_query($CONNECT, "UPDATE `numeklatura` SET `value` = '$_POST[title]' WHERE `numeklatura`.`id` = '$_POST[id]'") === TRUE) {
    printf("oks");
  } else {
    echo 'Ошибка';
  }
}
if ($_GET['razdel'] == 'load_edit') {
  $result = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `id` = $id  ");
  $resp = array();
  while ($line = mysqli_fetch_assoc($result)) {;
    $resp = $line;
    //tt($resp);
  }
  echo json_encode($resp);
}
