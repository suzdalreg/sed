<?php
include_once '../../setting.php';
$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
include("../../path.php");

$date = new DateTime();
$data = $date->format('Y-m-d');
$mon = ($date->format('n'));
$date1 = $date->modify('+ 1day');
$datOne = $date1->format('Y-m-d');
$date->modify('+4 day');
$dat = $date->format('Y-m-d');

//tt($_GET);
$title = $_GET['data'];

//if (!empty($_GET['arg'])) {
if ($_GET['sesion'] == 'admin') {
  $q = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `mon` = '$_GET[mon]' AND `year` = '$_GET[year]' ORDER BY `regdate` DESC ");
} elseif ($_GET['sesion'] == 'arx'  || 'kumi') {

  $q = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `otdel` = '$_GET[sesion]' AND `report` = '' ORDER BY `regdate` DESC ");
  //echo 'отдел';
}
if (!empty($_GET['per'])) {
  $q = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `mon` = '$_GET[mes]' AND `year` = '$_GET[god]' ORDER BY `regdate` DESC ");
}
if (!empty($_GET['today'])) {
  $q = mysqli_query($CONNECT, "SELECT * FROM `info`  WHERE  `srok` = '{$data}' ORDER BY `regdate` DESC ");
}
if (!empty($_GET['uprok'])) {
  $q = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `srok` BETWEEN '$datOne' AND '$dat'  ");
}
if ($_GET['select'] == 'an') {
  $q = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `title` LIKE '%" . $title . "%' ORDER BY `regdate` DESC  ");
}
if ($_GET['select'] == 'ix_n') {
  $q = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `out_num` LIKE '%" . $title . "%' ORDER BY `regdate` DESC  ");
}
if ($_GET['select'] == 'vx_n') {
  $q = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `in_nomer` LIKE '%" . $title . "%' ORDER BY `regdate` DESC  ");
}
if ($_GET['select'] == 'ix_d') {
  $q = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `out_date` = '$title'  ORDER BY `regdate` DESC  ");
}
if ($_GET['select'] == 'vx_d') {
  $q = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `in_date` = '$title'  ORDER BY `regdate` DESC  ");
}
if ($_GET['select'] == 'org') {
  $q = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `org` LIKE '%" . $title . "%'   ORDER BY `regdate` DESC  ");
}
if ($_GET['select'] == 'srok') {
  $q = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `srok` = '$title'  ORDER BY `regdate` DESC  ");
}
if ($_GET['isp'] == 'все') {
  // $q = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE   report = '' ORDER BY `regdate` DESC ");
  $q = mysqli_query($CONNECT, "SELECT * FROM `user` INNER JOIN `info` ON id_info = info.id WHERE info.report = '' AND user.otv ='checked' AND `srok` < CURRENT_DATE() ORDER BY `regdate` DESC ");
  //echo 'все';
}
if ($_GET['isp'] == 'пустые') {
  $q = mysqli_query($CONNECT, "SELECT * FROM `info` LEFT JOIN `user` ON id_info = info.id WHERE user.ispolnitel IS NULL AND info.report='' AND `srok` < CURRENT_DATE()");
  //echo 'пусто';
}
if (!empty($_GET['isp']) && ($_GET['isp'] !== "все") && ($_GET['isp'] !== "пустые")) {
  $q = mysqli_query($CONNECT, "SELECT * FROM `user` INNER JOIN `info` ON id_info = info.id WHERE info.report = '' AND user.otv ='checked' AND user.ispolnitel = '$_GET[isp]' AND `srok` < CURRENT_DATE() ORDER BY `regdate` DESC ");
  //echo 'исполнители';
}
while ($row = mysqli_fetch_array($q)) {
  $qwery = mysqli_query($CONNECT, "SELECT * FROM `user` WHERE `id_info` = '{$row['id']}' ORDER BY `user`.`otv` DESC");
  //tt($row);
  echo '
    <tr id = "stroka">    
      <td> ' . $row[out_num] . '</td>
      <td> ' . convert_date($row[out_date]) . '</td>
      <td> ' . $row[in_nomer] . '</td>
      <td> ' . convert_date($row[in_date]) . '</td>
      <td> ' . $row[vid_doc] . '</td>
      <td> ' . $row[org] . '</td>
      <td> ' . $row[title] . '</td>
      <td> ' . convert_date($row[srok]) . '</td>      
      <td   style="width:120px;"  >';
  foreach ($qwery as  $ll) {
    //tt($ll);
    echo ($ll[ispolnitel]);
    echo '<br>';
  } ?>

  </td>
  <td> <?= $row[report] ?></td>
  <td><?php if ($_SESSION['USER_tip'] == 'admin') { ?> <a href="print.php?id=<?= $row[id] ?>" target="_blank"><img src="/app/print.png" alt="" width="20" height="20"></a> <?php  };  ?>
    <img src="app/down.png" alt="" width="20" height="20" onclick="view_file(<?= $row[id] ?> )">
    <img src="app/edit.png" alt="" width="18" height="18" onclick="edit_info(<?= $row[id] ?> )">
    <?php if ($_SESSION['USER_tip'] == 'admin') { ?> <img src="app/delete.png" alt="" width="18" height="18" onclick="del_info(<?= $row[id] ?> )"><?php  };  ?>
  </td>

  </tr>
<?php
}
?>