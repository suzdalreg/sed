<?php
include_once '../../setting.php';
$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
include("../../path.php");
//tt($_GET);
$q = mysqli_query($CONNECT, "SELECT * FROM `user` WHERE `id_info` = '$_GET[id]'");
$l = mysqli_fetch_all($q);
if (!empty($l)) {
  echo '
<table id="tabll" class="table table-hover" style="margin-top: 10px;" >
  <thead class="head_sprav" style="font-size: 13px;">
    <tr>
      <th scope="col">Автор резолюции</th>
      <th scope="col">Резолюция</th>
      <th scope="col">Дата резолюции</th>
      <th scope="col">Исполнитель</th>
      <th scope="col">Дата передачи</th>
      <th scope="col">Гл. исполнитель</th>
      <th scope="col">Действие</th>
    </tr>
  </thead>
  <tbody class="tbody">
  ';
}
$i = 0;
foreach ($l as  $ll) {
  $i++;
  //tt($ll);
  echo '       
      <tr>    
        <td> ' . $ll[2] . '</td>
        <td> ' . $ll[3] . '</td>
        <td> ' . convert_date($ll[4]) . '</td>
        <td> ' . $ll[5] . '</td>
        <td> ' . convert_date($ll[6]) . '</td>
        <td>         
        <input  class="form-check-input" style = "margin-left:20%;" type="radio" onchange="ch(' . $ll[0] . ')" name="exampleRadios" id="exampleRadios1" value="option' . $i . '" ' . $ll[7] . '>      
          </td>     
        <td> <img src="app/delete.png" style = "margin-left:20%;" alt="" width="18" height="18" onclick="del_isp(' . $ll[0] . ')"> </td>  
      </tr>
      ';
}
?>
</tbody>
</table>