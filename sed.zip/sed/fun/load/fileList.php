﻿<?php include_once '../../setting.php';
$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
include("../../path.php");

$id = $_GET['id'];
$year = $_GET['year'];
$baseFile = 'file' . $year;
$baseInfo = 'info' . $year;
$mon = $_GET['mon'];
?>


<tbody>
  <?php
  $result = mysqli_query($CONNECT, "SELECT * FROM `info`   LEFT JOIN  `file` ON `info`.`id`= `file`.`id_zapisi` WHERE `id_zapisi`=" . $id . "  AND `id`=" . $id . "  ");
  while ($li = mysqli_fetch_array($result)) {
    //tt($row);
    echo '
    <tr>    
      <td> <a class="list" href="/file/' . $year . '/' . $mon . '/' . $li[id] . '/' . $li[name] . '  " download ="' . $li[original_name] . '" >' . $li[original_name] . ' </a> 	</td>
      <td> <img src="app/delete.png" alt="" width="15" height="15" onclick="del_file(' . $li[idf] . ',' . $li[id] . ' )"> <br> </td>      
    </tr>
    ';
  }
  ?>
</tbody>