<?php
include_once '../../setting.php';
$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
include("../../path.php");
?>

<thead class="head_sprav">
  <tr>
    <th scope="col">Название</th>
    <th scope="col" style="width: 90px;">Действие</th>
  </tr>
</thead>
<tbody class="tbody">
  <?php
  $q = mysqli_query($CONNECT, "SELECT * FROM `numeklatura` ORDER BY `numeklatura`.`value` ASC ");
  $l = mysqli_fetch_all($q);
  foreach ($l as  $li) {
    echo '
    <tr>    
      <td> ' . $li[1] . '</td>
      <td><img src="app/edit.png" style = "margin-left:30%;" alt="" width="18" height="18" onclick="edit_org(  3  ,' . $li[0] . ' )" >
      <img src="app/delete.png" alt="" width="18" height="18" onclick="del_org(3,' . $li[0] . ')">  </td>      
    </tr>
    ';
  }
  ?>
</tbody>