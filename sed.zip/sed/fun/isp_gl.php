<?php
include_once '../setting.php';
$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
include("../path.php");
//tt($_GET);
$q = mysqli_query($CONNECT, "UPDATE `user` SET `otv` = '' WHERE `id_info` = '$_GET[id_info]'");
$w = mysqli_query($CONNECT, "UPDATE `user` SET `otv` = 'checked' WHERE `id_u` = '$_GET[id]'");
echo 'ok';
