﻿<?php include_once '../setting.php';
include("../path.php");
$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
$mydata = json_decode(file_get_contents("php://input"), true);

//tt($mydata);
if ($mydata['org'] == '1') {
  $res = mysqli_query($CONNECT, " DELETE FROM `org` WHERE `org`.`id` = '$mydata[id]' ");
  if ($res == 1) {
    echo 'del_org';
  } else {
    echo 'Error_del_org';
  }
}
if ($mydata['org'] == '2') {
  $res = mysqli_query($CONNECT, " DELETE FROM `person` WHERE `person`.`id` = '$mydata[id]' ");
  if ($res == 1) {
    echo 'del_person';
  } else {
    echo 'Error_del_org';
  }
}
if ($mydata['org'] == '3') {
  $res = mysqli_query($CONNECT, " DELETE FROM `numeklatura` WHERE `numeklatura`.`id` = '$mydata[id]' ");
  if ($res == 1) {
    echo 'del_num';
  } else {
    echo 'Error_del_org';
  }
}
if ($mydata['org'] == 'delf') {
  $res = mysqli_query($CONNECT, " DELETE FROM `file` WHERE `idf` = '$mydata[id_file]' AND `id_zapisi` = '$mydata[id_zapisi]' ");
  if ($res == 1) {
    echo 'del_file';
  } else {
    echo 'Error_del';
  }
}
if ($mydata['org'] == 'delzap') {
  $res = mysqli_query($CONNECT, " DELETE FROM `info` WHERE `id` = '$mydata[id]' ");
  $result = mysqli_query($CONNECT, " DELETE FROM `file` WHERE `id_zapisi` = '$mydata[id]' ");
  if ($res == 1) {
    echo 'del_zap';
  } else {
    echo 'Error_del';
  }
}
if ($mydata['org'] == 'del_info') {
  $result = mysqli_query($CONNECT, " DELETE FROM `info` WHERE `id` = '$mydata[id]' ");
  if ($result == 1) {
    echo 'del_info';
  } else {
    echo 'Error_del';
  }
}
if ($_GET['info'] == 'del_isp') {
  $res = mysqli_query($CONNECT, " DELETE FROM `user` WHERE `user`.`id_u` = '$_GET[id]' ");
  if ($res == 1) {
    echo 'ok';
  } else {
    echo 'Error_del_org';
  }
}
