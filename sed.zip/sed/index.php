﻿<?php
session_start();
include_once 'setting.php';

$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
include("path.php");


?>
<!doctype html>
<html lang="ru">

<head>
  <!-- Required meta tags -->

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="src/css/bootstrap.min.css">

  <link rel="stylesheet" href="src/css/style.css">
  <link rel="stylesheet" href="src/css/dselect.css">


  <title>СЭД район</title>
</head>

<body>
  <?php include("app/include/header.php"); ?>
  <input type="hidden" id="sesName" value="<?= $_SESSION['USER_tip'] ?>">
  <div class="container-fluid">
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['button-log'])) {

      $login = trim($_POST['login']);
      $password = trim($_POST['password']);

      $Row = mysqli_fetch_assoc(mysqli_query($CONNECT, "SELECT `pass` FROM `login` WHERE `user` = '$login'"));
      if ($Row['pass'] != $password) {
        $errMsg = "Логин либо пароль введены неверно!";
      } else {
        $Row = mysqli_fetch_assoc(mysqli_query($CONNECT, "SELECT  * FROM `login` WHERE `pass` = '$password' AND `user` = '$login' "));
        header('Location: /');
        //if ($_REQUEST['remember']) setcookie('user',$_POST['password'],strtotime('+30 days'), '/');
        $_SESSION['USER_NAME'] = $Row['user'];
        $_SESSION['USER_tip'] = $Row['tip'];
        $_SESSION['NAME'] = $Row['name'];
        $_SESSION['USER_LOGIN_IN'] = 1;
      }
    }

    if ($_SESSION['USER_LOGIN_IN'] == 0) { ?>
      <div class="container reg_form" style="min-height: 820px;">
        <form class="row justify-content-center" method="post" action="">

          <div class="mb-3 col-12 col-md-4 err">
            <p><?= $errMsg ?></p>
          </div>
          <div class="w-100"></div>
          <div class="mb-3 col-12 col-md-4">
            <label for="formGroupExampleInput" class="form-label">Логин</label>
            <input name="login" type="log" class="form-control" required placeholder="введите ваш логин...">
          </div>
          <div class="w-100"></div>
          <div class="mb-3 col-12 col-md-4">
            <label for="exampleInputPassword1" class="form-label">Пароль</label>
            <input name="password" type="password" class="form-control" id="exampleInputPassword1" required placeholder="введите ваш пароль...">
          </div>
          <div class="w-100"></div>
          <div class="mb-3 col-12 col-md-4">
            <button type="submit" name="button-log" class="btn btn-secondary">Войти</button>

          </div>
        </form>
      </div>
    <?php } else { ?>
      <div class="content row">

        <!-- Main Content -->
        <div class="main-content col-md-12 ">
          <div id="loader23"><span></span></div>
          <!-- Хлебные крошки-->
          <nav aria-label="breadcrumb" style="margin-top: 10px;">
            <ol class="breadcrumb">
              <li class="breadcrumb-item active" aria-current="page">Входящие</li>
              <li class="breadcrumb-item active" id="y" aria-current="page"></li>
              <li class="breadcrumb-item active" id="m" aria-current="page"></li>
            </ol>
          </nav>
          <!--Конец- Хлебные крошки-->
          <?php if ($_SESSION['USER_tip'] == 'admin') { ?>
            <div class="row">
              <div class="col">

                <input type="button" value="Добавить запись" onclick="inzert() " id="btm_in" class="btn btn-warning btn-sm" style="margin-bottom: 14px; ">

              </div>
              <div class="col" id="pereh" style="float:left; color:#db5830; font-size:13pt ">
              </div>
              <div class="col">
                <input type='hidden' value="Експорт в Excel" onclick="exel() " id="xl" class="btn btn-success btn-sm">
              </div>

              <div class="col">
                <button class="btn btn-primary btn-sm" style="float:right ; margin-bottom: 14px;" type="button" onclick="saitbar()">Меню</button>
              </div>
            </div>

          <?php  };  ?>
          <div class="table-responsive">
            <table>
              <table id="tabll" class="table table-hover">
                <thead class="head_sprav" style="font-size: 13px;">
                  <tr>
                    <th scope="col" style="width: 120px;">Исх.№</th>
                    <th scope="col" style="width: 100px;">Исх.Дата</th>
                    <th scope="col" style="width: 70px;">Вх.№</th>
                    <th scope="col" style="width: 100px;">Вх. Дата</th>
                    <th scope="col" style="width: 100px;">Вид документа</th>
                    <th scope="col" style="width: 160px;">Организация</th>
                    <th scope="col">Аннотация</th>
                    <th scope="col" style="width: 120px;">Срок</th>
                    <th scope="col">Исполнители</th>
                    <th scope="col" style="width: 150px;">Отчет об исполнении</th>
                    <th scope="col" style="width: 110px;">Операции</th>
                  </tr>
                </thead>
                <tbody id="tbody" class="tbody">
                </tbody>
              </table>
          </div>
        </div>
      </div>
  </div>




  <?php include("app/include/footer.php"); ?>
  <!-- Модал добавления -->
  <?php include("app/include/in.php"); ?>
  <!-- Модал добавления -->

  <!-- Модал файлов -->
  <?php include("app/include/file.php");  ?>
  <!-- Модал файлов -->
  <!-- Модал изменения -->
  <?php include("app/include/edit.php");   ?>
  <!-- Модал изменения -->

  <!-- Уведомление пусто-->
  <div class="toast" id="pusto" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="2000" style="display:block;position:fixed;z-index: 1060; bottom:91%;right:40%; text-align: center; font-size: 17px;">
    <div class="toast-body" style=" background-color:#34adb3;">
      Заполните поля!
    </div>
  </div>
  <!-- конец  -->
  <!-- Уведомление -->
  <div class="toast" id="uved" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="2000" style="display:block;position:fixed; bottom:90%;right:50%; text-align: center; font-size: 17px;">
    <div class="toast-body " id="ed" style=" background-color: rgb(140, 221, 147);">
      Выполнено успешно!
    </div>
  </div>
  <!-- Уведомление конец -->
  <!-- Modal для удаления-->
  <div class="modal fade" id="del_inf" tabindex="-1" aria-labelledby="exampleModalLabel12" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Внимание!</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" id="del_clos" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Вы действительно хотите удалить запись ?
        </div>
        <div class="modal-footer">
          <input type="submit" style="width: 100px;" value="Удалить" class="btn btn-danger  " id="del_btm">
        </div>
      </div>
    </div>
  </div>
  <!-- Modal конец -->
  <!-- Modal для удаления файлов-->
  <div class="modal fade" id="del_f" tabindex="-1" aria-labelledby="exampleModalLabel12" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Внимание!</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" id="del_clos" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Вы действительно хотите удалить запись ?
        </div>
        <div class="modal-footer">
          <input type="submit" style="width: 100px;" value="Удалить" class="btn btn-danger  " id="del_btm_f">
        </div>
      </div>
    </div>
  </div>
  <!-- Modal конец -->
  <!-- Mеню-->
  <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
    <div class="offcanvas-header" style="background:#5da8bfab ;">
      <h5 class="offcanvas-title" id="offcanvasRightLabel">Меню</h5>
      <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Закрыть"></button>
    </div>
    <div class="offcanvas-body" style="background:#f6f6f6 ;">

      <button type="button" class="btn btn-primary btn-sm position-relative" id="todays">
        Сегодня
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="tod">
        </span>
      </button>
      <br>
      <button type="button" style="margin-top:5px ;" class="btn btn-primary btn-sm position-relative" id="upr">
        Упреждающие
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="upre">
        </span>
      </button>
      <hr>
      <div class="section search">
        <h5>Поиск по:</h5>
        <select name="num" id="select" class="form-control">
          <option value="an">Аннотации</option>
          <option value="ix_n">Исх. номер</option>
          <option value="vx_n">Вх. номер</option>
          <option value="ix_d">Исх. Дата</option>
          <option value="vx_d">Вх. Дата</option>
          <option value="org">Организации</option>
          <option value="srok">Срок</option>
        </select>
        <br>
        <input id="hybrid" type="text" autocomplete="off" name="info" class="form-control" required>
        <br>
        <input type="button" value="Найти" class="btn btn-primary " id="search">

      </div>

      <div class="section search" style="margin-top:10px ;">
        <h5> Поиск незакрытых записей</h5>
        <select name="glavnie" id="glavn" class="form-control">
          <option value="все">Все</option>
          <option value="пустые">Без исполнителей</option>
          <?php
          $sp = mysqli_query($CONNECT, "SELECT DISTINCT ispolnitel FROM `user` INNER JOIN `info` ON id_info = info.id WHERE report = '' AND otv ='checked' ORDER BY `user`.`ispolnitel` ASC");
          // $pr = mysqli_fetch_all($sp);
          while ($row = mysqli_fetch_array($sp)) {
            //tt($lp);
            echo '
                <option value="' . $row[ispolnitel] . '">' . $row[ispolnitel] . '</option>
                 ';
          }
          ?>
        </select>
        <input type="button" style="margin-top: 10px;" value="Найти" class="btn btn-primary " id="glav">
      </div>

      <div class="section search" style="margin-top:10px ;">
        <ul style="list-style-type:none">
          <h5> Перейти в:</h5>
          <?php $resultY = mysqli_query($CONNECT, "SELECT DISTINCT year FROM `info` ORDER BY `info`.`year` DESC");
          $lineY = mysqli_fetch_all($resultY);
          //tt($lineY);
          $i = 1;
          foreach ($lineY as  $lin) {
            $i++;
          ?>
            <li><a data-bs-toggle="collapse" href="#z1<?= $i ?>"> за <?= $lin['0'] ?> год</a></li>
            <div class="collapse" id="z1<?= $i ?>">
              <li>
                <ol style="list-style-type:none">
                  <li type="button" onclick="perehod(0,<?= $lin['0'] ?>)">Январь</li>
                  <li type="button" onclick="perehod(1,<?= $lin['0'] ?>)">Февраль</li>
                  <li type="button" onclick="perehod(2,<?= $lin['0'] ?>)">Март</li>
                  <li type="button" onclick="perehod(3,<?= $lin['0'] ?>)">Апрель</li>
                  <li type="button" onclick="perehod(4,<?= $lin['0'] ?>)">Май</li>
                  <li type="button" onclick="perehod(5,<?= $lin['0'] ?>)">Июнь</li>
                  <li type="button" onclick="perehod(6,<?= $lin['0'] ?>)">Июль</li>
                  <li type="button" onclick="perehod(7,<?= $lin['0'] ?>)">Август</li>
                  <li type="button" onclick="perehod(8,<?= $lin['0'] ?>)">Сентябрь</li>
                  <li type="button" onclick="perehod(9,<?= $lin['0'] ?>)">Октябрь</li>
                  <li type="button" onclick="perehod(10,<?= $lin['0'] ?>)">Ноябрь</li>
                  <li type="button" onclick="perehod(11,<?= $lin['0'] ?>)">Декабрь</li>
                </ol>
              </li>
            </div>
          <?php
          }
          ?>
        </ul>
      </div>

    </div>
  </div>
  <!-- Mеню-->
<?php  }
?>
<script src="src/js/bootstrap.bundle.min.js"></script>
<script src="src/js/dselect.js"></script>
<script src="src/js/main.js?v=<?= time() ?>"></script>
<script>
  window.onload = function() {
    arg = !arg;
    loadInf('<?= $_SESSION['USER_tip'] ?>')
    document.getElementById('btm_in').type = 'button';

  };
</script>
<script>
  dselect(document.querySelector('#search_org'), {
    search: true
  })
  dselect(document.querySelector('#example-search'), {
    search: true
  })
  for (const el of document.querySelectorAll('.dselect')) {
    dselect(el)
  }

  void(function() {
    document.querySelectorAll('.needs-validation').forEach(form => {
      form.addEventListener('submit', event => {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }
        form.classList.add('was-validated')
      })
    })
  })()
</script>
<a href="#top" style="display:block;position:fixed;
        /*положение кнопки*/
        bottom:30px;right:30px;                       
        -webkit-border-radius:15px;
        -moz-border-radius:15px;
        border-radius:10px"><img src="../../app/up.png" alt="" width="65" height="65"></a>
</body>

</html>