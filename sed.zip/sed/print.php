<?php include_once 'setting.php';

$CONNECT = mysqli_connect(HOST, USER, PASS, DB);
include("path.php");

?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Просмотр печати</title>
</head>

<body>
    <?php
    $q = mysqli_query($CONNECT, "SELECT * FROM `user` WHERE `id_info` = '$_GET[id]' ORDER BY `user`.`otv` DESC");

    $result = mysqli_query($CONNECT, "SELECT * FROM `info` WHERE `id` = '$_GET[id]'  ");
    $line = mysqli_fetch_assoc($result);

    ?>
    <style>
        table.iksweb {
            font-size: 14px;
            width: 720px;
            border-collapse: collapse;
            border-spacing: 0;
            height: auto;
        }

        h2 {
            text-align: center;
            margin-block-start: 0em;
            font-weight: 400;

        }

        hr {
            border-top: 1px dashed;
            width: 720px;
            margin: 0px;
        }

        table.iksweb,
        table.iksweb td,
        table.iksweb th {
            /*   border: 1px solid #595959; */
            padding: 3px;
        }

        table.iksweb1 {
            margin-top: 5px;
            font-size: 14px;
            width: 720px;
            border-collapse: collapse;
            border-spacing: 0;
            height: auto;
        }

        table.iksweb1,
        table.iksweb1 td,
        table.iksweb1 th {
            border: 1px solid #595959;
        }

        table.iksweb1 th {
            background: #347c99;
            color: #fff;
            font-weight: normal;
        }
    </style>
    <table class="iksweb">
        <tbody>
            <tr>
                <td colspan="4">
                    <h2> Карточка входящего документа</h2>
                </td>
            </tr>
            <tr>
                <td colspan="2" rowspan="2"></td>
                <td style="width: 220px;"> <b> Рег.№: </b><?= $line['in_nomer'] ?></td>
                <td style="width: 220px;"><b> Рег.дата: </b><?= convert_date($line['in_date']) ?></td>
            </tr>
            <tr>
                <td> <b> Исх.№: </b><?= $line['out_num'] ?></td>
                <td><b> Исх. дата: </b><?= convert_date($line['out_date']) ?></td>
            </tr>
            <tr>
                <td style="width: 150px;"><b> Организация:</b></td>
                <td colspan="3"> <?= $line['org'] ?> </td>

            </tr>
            <tr>
                <td><b> Срок исполнения:</b></td>
                <td colspan="3"> <?= convert_date($line['srok']) ?> </td>

            </tr>
        </tbody>
    </table>
    <hr>
    <table class="iksweb">
        <tbody>

            <tr>
                <td style="width: 150px;"><b> Вид документа:</b></td>
                <td> <?= $line['vid_doc'] ?> </td>

            </tr>
            <tr>
                <td><b> Номенклатура:</b></td>
                <td> <?= $line['nomenklatura'] ?> </td>
            </tr>
            <tr>
                <td><b> Аннотация:</b></td>
                <td> <?= $line['title'] ?> </td>
            </tr>
        </tbody>
    </table>
    <hr style="margin-bottom: 5px ;">
    <b> Справка об исполнении и контроле документа</b>
    <table class="iksweb1">
        <tbody>
            <tr style="text-align: center ; ">
                <td style="width: 30px;"> <b> №</b></td>
                <td style="width: 110px;"> <b> Дата передачи</b></td>
                <td> <b> ФИО участников, текст поручения</b></td>
                <td style="width: 120px;"> <b> Дата резолюции</b></td>
            </tr>
            <?php
            $i = 0;
            while ($row = mysqli_fetch_array($q)) {
                // tt($row);
                $i++;
                echo ' 
            <tr>
                <td style="text-align: center ; vertical-align: top;"><b>' . $i . '</b></td>
                <td style="text-align: center ; vertical-align: top;">' . convert_date($row[date_per]) . '</td>
                <td>
                    <b> Автор: </b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $row[avtor] . '
                    <br>
                    <b> Исполнитель:</b> &nbsp;&nbsp; <b>' . $row[ispolnitel] . '</b>
                    <br>
                    <b> Текст:</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $row[rez] . '
                </td>
                <td style="text-align: center ; vertical-align: top;">' . convert_date($row[date_rez]) . '</td>
            </tr>
            ';
            }
            ?>
        </tbody>
    </table>
    <hr style="margin-top: 15px ;">


</body>

</html>
<script>
    print();
</script>